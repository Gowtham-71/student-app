package com.crud.controller;


import com.crud.modal.Student;
import com.crud.repository.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@CrossOrigin(origins = "http://localhost:3000")
@RestController
@RequestMapping("/api/students")
public class StudentController {

    @Autowired
    private StudentRepository studentRepository;

    @GetMapping
    public List<Student> getAll(){
        return studentRepository.findAll();
    }

    @PostMapping
    public Student create(@RequestBody Student student){
        return studentRepository.save(student);
    }

    @GetMapping("/filter")
    public List<Student> filterByDepartment(@RequestParam String department){
        return studentRepository.findByDepartment(department);
    }

    @GetMapping("/search")
    public List<Student> searchByName(@RequestParam String keyword){
        return studentRepository.findByNameContainingIgnoreCase(keyword);
    }

    @GetMapping("/sort")
    public List<Student> sortByGpa(@RequestParam(defaultValue = "asc") String order){
        return order.equals("desc") ? studentRepository.findAll(Sort.by(Sort.Direction.DESC, "gpa")) :
                                         studentRepository.findAll((Sort.by(Sort.Direction.ASC, "gpa")));
    }

}
